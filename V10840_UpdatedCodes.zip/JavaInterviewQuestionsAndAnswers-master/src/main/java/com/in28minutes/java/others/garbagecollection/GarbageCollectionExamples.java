package com.in28minutes.java.others.garbagecollection;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class GarbageCollectionExamples {
	void method() {
		Calendar calendar = new GregorianCalendar(2000, 10, 30);
		System.out.println(calendar);
	}
}
