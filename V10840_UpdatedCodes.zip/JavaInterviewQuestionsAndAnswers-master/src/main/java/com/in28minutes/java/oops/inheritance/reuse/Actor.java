package com.in28minutes.java.oops.inheritance.reuse;

public class Actor {
	public void act() {
		System.out.println("Act");
	};
}
