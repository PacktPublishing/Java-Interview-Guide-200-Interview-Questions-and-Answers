package com.in28minutes.java.oops.interfaces;

public class InterfaceExamples {
	public static void main(String[] args) {
		Flyable flyable = new Bird();
		flyable.fly();
	}
}
